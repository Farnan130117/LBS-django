from django.db import models

# Create your models here.
class Product(models.Model):     #product_class
	title = models.CharField(max_length=200, null=True)
	description = models.CharField(max_length=400, null=True)
	image = models.ImageField(blank=True)    
	  #pip install pillow
	  #Pillow is a Python Imaging Library which deals with different image files. 
	  #We won’t be using pillow directly but Django is using it. Therefore, we need pillow library.				
	available	=	models.BooleanField(default=True)
	created	=	models.DateTimeField(auto_now_add=True)				
	updated	=	models.DateTimeField(auto_now=True)
	#date_created = models.DateTimeField(default=datetime.now(), null=True,  editable=False)
	#date_created = models.DateTimeField(auto_now_add=True, null=True)
     
	def __str__(self):
		return self.title
	class Meta:
		db_table = "product"

class ProductImage(models.Model):
    product = models.ForeignKey(Product, default=None, on_delete=models.CASCADE)
    images = models.FileField(upload_to = 'images/')

    def __str__(self):
        return self.product.title

class Area(models.Model):     #area_class
	name = models.CharField(max_length=200, null=True)
	description = models.CharField(max_length=400, null=True)			
	available	=	models.BooleanField(default=True)
	created	=	models.DateTimeField(auto_now_add=True)				
	updated	=	models.DateTimeField(auto_now=True)
	#date_created = models.DateTimeField(default=datetime.now(), null=True,  editable=False)
	#date_created = models.DateTimeField(auto_now_add=True, null=True)
     
	def __str__(self):
		return self.name
	class Meta:
		db_table = "area"

class Vendor(models.Model):     #vendor_class
	name = models.CharField(max_length=200, null=True)
	description = models.CharField(max_length=400, null=True)
	location = models.CharField(max_length=400, null=True)				
	available	=	models.BooleanField(default=True)
	created	=	models.DateTimeField(auto_now_add=True)				
	updated	=	models.DateTimeField(auto_now=True)
	#date_created = models.DateTimeField(default=datetime.now(), null=True,  editable=False)
	#date_created = models.DateTimeField(auto_now_add=True, null=True)
     
	def __str__(self):
		return self.name
	class Meta:
		db_table = "vendor"

class PriceInformation(models.Model):     #price_information_class	
	vendor = models.ForeignKey(Vendor,
                              related_name='vendor',
                              on_delete=models.CASCADE)
	product = models.ForeignKey(Product,related_name='product',on_delete=models.CASCADE)
	price = models.DecimalField(max_digits=10, decimal_places=2, null=True)
	area = models.ForeignKey(Area,related_name='area',on_delete=models.CASCADE)
	available	=	models.BooleanField(default=True)
	created	=	models.DateTimeField(auto_now_add=True)				
	updated	=	models.DateTimeField(auto_now=True)
	#date_created = models.DateTimeField(default=datetime.now(), null=True,  editable=False)
	#date_created = models.DateTimeField(auto_now_add=True, null=True)
	def __str__(self):
		return str(self.vendor)+" | "+str(self.area)+" | "+str(self.product)+" | "+str(self.price)
	class Meta:
		db_table = "price_info"

class MultipleSearchInformation(models.Model):     #price_information_class
	vendor = models.CharField(max_length=200, null=True)
	product = models.CharField(max_length=200, null=True)
	price = models.DecimalField(max_digits=10, decimal_places=2)
	area = models.CharField(max_length=200, null=True)
	available	=	models.BooleanField(default=True)
	created	=	models.DateTimeField(auto_now_add=True)
	updated	=	models.DateTimeField(auto_now=True)
	#date_created = models.DateTimeField(default=datetime.now(), null=True,  editable=False)
	#date_created = models.DateTimeField(auto_now_add=True, null=True)
     
	class Meta:
		managed = False
     
	

