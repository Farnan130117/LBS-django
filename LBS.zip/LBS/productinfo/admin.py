from django.contrib import admin
from .models import	*
# Register your models here.

#admin.site.register(Product)


class ProductImageAdmin(admin.StackedInline):
    model = ProductImage
 
@admin.register(Product)
class PostAdmin(admin.ModelAdmin):
    inlines = [ProductImageAdmin]
 
    class Meta:
       model = Product
 
@admin.register(ProductImage)
class ProductImageAdmin(admin.ModelAdmin):
    pass

admin.site.register(Area)
admin.site.register(Vendor)
admin.site.register(PriceInformation)