from django.apps import AppConfig


class ProductinfoConfig(AppConfig):
    name = 'productinfo'
