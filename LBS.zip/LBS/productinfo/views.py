from django.shortcuts import render, redirect , get_object_or_404
from django.views.decorators.http import require_POST
from django.http import HttpResponse
from productinfo.models import MultipleSearchInformation,Area,Product,ProductImage



# Create your views here.


def home(request):
	if request.method=="POST":
		area=request.POST.get('area')
		all_area=Area.objects.raw('select * from lbsdb.area')
		product=request.POST.get('product')
		all_product=Product.objects.raw('select * from lbsdb.product')
		if area!="-- select area --" and product!="-- select product --":
			#print("AND")
			custom_search_model= MultipleSearchInformation.objects.raw('select price_info.id,price_info.product_id,vendor.name as vname, price_info.vendor_id as vid, product.title as ptitle,price_info.price as price,area.name as aname from lbsdb.price_info join lbsdb.product on product.id= price_info.product_id join lbsdb.vendor on vendor.id= price_info.vendor_id join lbsdb.area on area.id= price_info.area_id where area.name="'+area+'" and product.title="'+product+'"')
		elif area=="-- select area --" and product!="-- select product --":
			#print(product)
			custom_search_model= MultipleSearchInformation.objects.raw('select price_info.id,price_info.product_id,vendor.name as vname, price_info.vendor_id as vid, product.title as ptitle,price_info.price as price,area.name as aname from lbsdb.price_info join lbsdb.product on product.id= price_info.product_id join lbsdb.vendor on vendor.id= price_info.vendor_id join lbsdb.area on area.id= price_info.area_id where product.title="'+product+'"')
		elif area!="-- select area --" and product=="-- select product --":
			#print(area)
			custom_search_model= MultipleSearchInformation.objects.raw('select price_info.id,price_info.product_id,vendor.name as vname, price_info.vendor_id as vid, product.title as ptitle,price_info.price as price,area.name as aname from lbsdb.price_info join lbsdb.product on product.id= price_info.product_id join lbsdb.vendor on vendor.id= price_info.vendor_id join lbsdb.area on area.id= price_info.area_id where area.name="'+area+'"')
		else:
			print("else")
			custom_search_model= MultipleSearchInformation.objects.raw('select price_info.id,price_info.product_id,vendor.name as vname, price_info.vendor_id as vid, product.title as ptitle,price_info.price as price,area.name as aname from lbsdb.price_info join lbsdb.product on product.id= price_info.product_id join lbsdb.vendor on vendor.id= price_info.vendor_id join lbsdb.area on area.id= price_info.area_id')
		#product_image= Product.objects.raw('select * from lbsdb.productinfo_productimage')
		product_images = ProductImage.objects.all()
		return render(request,'productinfo/home.html',{"MultipleSearchInformation":custom_search_model,
			                                           "all_area":all_area,
			                                           "all_product":all_product,
			                                           "area":area,
			                                           "product":product,
			                                           "product_images":product_images})
	else:
		custom_model= MultipleSearchInformation.objects.raw('select price_info.id,price_info.product_id,vendor.name as vname, price_info.vendor_id as vid, product.title as ptitle,price_info.price as price,area.name as aname from lbsdb.price_info join lbsdb.product on product.id= price_info.product_id join lbsdb.vendor on vendor.id= price_info.vendor_id join lbsdb.area on area.id= price_info.area_id')
		area="-- select area --"
		product="-- select product --"
		all_area=Area.objects.raw('select * from lbsdb.area')
		all_product=Product.objects.raw('select * from lbsdb.product')
		product_images = ProductImage.objects.all()
		return render(request, 'productinfo/home.html',{"MultipleSearchInformation":custom_model,
			                                            "all_area":all_area,
			                                            "all_product":all_product,
			                                            "area":area,
			                                            "product":product,
			                                            "product_images":product_images})